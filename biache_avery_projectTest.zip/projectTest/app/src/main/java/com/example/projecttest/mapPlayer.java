package com.example.projecttest;

public class mapPlayer
{
    //the player on the map
}
