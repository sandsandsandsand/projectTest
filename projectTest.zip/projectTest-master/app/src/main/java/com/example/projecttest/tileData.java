package com.example.projecttest;

public class tileData
{
    //methods that mapButtons execute when pressed
    //only execute if player is next to mapButton
}
