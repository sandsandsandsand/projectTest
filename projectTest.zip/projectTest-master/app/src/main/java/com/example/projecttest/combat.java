package com.example.projecttest;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
public class combat extends AppCompatActivity{
    private pokedigimon me,nme;//me is my mon and nme is the enemy mon
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fighting);
        updateView();
    }
    public void updateView(){

    }
}
