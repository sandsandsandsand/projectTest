package com.example.projecttest;

public class item
{
    public String name = "default";
}
