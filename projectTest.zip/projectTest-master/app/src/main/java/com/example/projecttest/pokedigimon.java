package com.example.projecttest;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class pokedigimon extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fighting);
    }
    int speed=0;
    int str=0;
    int health=0;
    int def=0;
    int fight=3;
    String name="default";
    public pokedigimon(int newSpeed, int newStrength, int newHealth, int newDefense, String newname)
    {
       speed=newSpeed;
        str=newStrength;
        health=newHealth;
        def=newDefense;
        name=newname;
    }
    public void FIGHT(View view)
    {
            Toast.makeText(this,"Firemon is attacking Watermon",Toast.LENGTH_LONG).show();
            if(this.fight<1)
                this.finish();//target.die();
            else{
                Toast.makeText(this,"Watermon attacked Firemon back",Toast.LENGTH_LONG).show();
                fight--;
            }
    }
    public int health(pokedigimon target){
        target.health=target.health-(this.str-target.def);
        if(target.health<1)
            return 0;//target.die();
        else
            return target.health;
    }
    public boolean swing(pokedigimon target){
        if(target.speed>this.speed)//code for deciding who goes first per turn
            return false;
        else if(target.speed==this.speed)
            return false;
        else
            return true;
    }
}
