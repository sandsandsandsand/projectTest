package com.example.projecttest;

import android.content.Context;

public class mapButtonWall
    extends mapButton
{

    public mapButtonWall(Context context) {
        super(context);
        setBackgroundResource(R.drawable.wall);
    }
}
